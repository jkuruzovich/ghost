# Static pages

Check the [page part](http://themes.ghost.org/v0.6.4/docs/page-context) in the Ghost Official Documentation.
