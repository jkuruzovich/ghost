# Links

Go to Ghost `Admin Panel` → `Navigation` and add/edit items.

"Blog" link is always included by default, so you don't need to add it manually.
