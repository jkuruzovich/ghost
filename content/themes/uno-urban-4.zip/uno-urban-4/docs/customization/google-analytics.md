# Google Analytics

Go to Ghost `Admin Panel` → `Code Injection` → `Blog Header` and add:

```html
<script>
var ga_id = 'UA-YOUR_ID_HERE';
</script>
```
