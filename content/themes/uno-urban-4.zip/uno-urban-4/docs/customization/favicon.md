# Favicon

Create your favicons with [Favicon Generator](http://realfavicongenerator.net/) and put it into `assets/img`.
