# Progress Bar

It's based on [Pace](http://github.hubspot.com/pace/docs/welcome).

You can change the theme of the progress bar easily replacing the CSS of `scss/components/_loading.scs`.
