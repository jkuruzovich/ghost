# Cover

Go to Ghost `Admin Panel` → General → `Blog Cover`.

The linear gradient of the cover filter is based in `$cover-primary` and `$cover-secondary` colors. If you want to adapt the filter for your cover, check [background-filter](https://github.com/Kikobeats/uno-zen/blob/master/assets/scss/modules/_utils.scss#L19) mixin.
