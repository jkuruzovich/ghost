# Posts Headline

By default, the title that you see in the page with your blog posts list is 'Writings.' but you might want to adjust this text.

If you want to customize it, you can do it:

Go to Ghost `Admin Panel` → `Code Injection` → `Blog Header` and add:

```html
<script>
var posts_headline = 'Random Stuff';
</script>
```
